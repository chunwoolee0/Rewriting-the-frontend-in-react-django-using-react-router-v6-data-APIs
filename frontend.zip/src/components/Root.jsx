import { useLoaderData, useSubmit, Form, Outlet, redirect } from "react-router-dom";

export async function loader({ request }) {
    const url = new URL(request.url);
    const q = url.searchParams.get("product_name")
    console.log('q : ', q);
    localStorage.setItem('q', q);
    return q;
}

export async function action() {
    return redirect(`/new`)
}

export default function Root() {
    const product_name = useLoaderData();
    const submit = useSubmit();
    return (
        <>
            <div id="sidebar">
                <h3>상품조회</h3>
                <div>
                    <Form id="search-form" role="search">
                        <input
                            id="product_name"
                            placeholder="조회"
                            type="search"
                            name="product_name"
                            defaultValue={product_name}
                            onChange={(event) => {
                                const isFirstSearch = product_name == null;
                                submit(event.currentTarget.form, {
                                    replace: !isFirstSearch,
                                })
                            }}
                        />
                    </Form>
                </div>
                <h3>상품등록</h3>
                <div>                    
                    <Form method="post">
                        <button type="submit">등록</button>
                    </Form>
                </div>
            </div>
            <div>
                <Outlet />
            </div>
        </>
    )
}