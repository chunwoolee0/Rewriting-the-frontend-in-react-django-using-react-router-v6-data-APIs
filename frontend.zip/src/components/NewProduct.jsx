import React from 'react';
import { useNavigate, Form, redirect } from 'react-router-dom';
import './main.css';

export async function action({ request }) {
  const formData = await request.formData();
  const data = Object.fromEntries(formData);
  console.log("formData obj: ", data);

  // formData.set("img", img.current.files[0]);
  formData.set("img", document.getElementById("img").files[0]);
  const f0 = formData.get('img')
  console.log('img file: ',  typeof f0, f0);
  try {
    const response = await fetch('http://localhost/insert', {
      method: 'post',
      encType: 'multipart/form-data',
      body: formData,                  
    });
  } catch (error) {
    if (error.message) {
      console.log(error.message);
    } else {
      console.log(error);
    }
  }
  return redirect("/");
}

export default function NewProduct() {
  const navigate = useNavigate();

  return (
    <>
      <h2>상품 정보 등록</h2>
      <Form method="post" id="product-form">
        <label>
            <span>상품명</span>
            <input
                type="text"
                name="product_name"
            />
        </label>
        <label>
            <span>가격</span>
            <input
                type="number"
                name="price"
            />
        </label>
        <label>
            <span>상품설명</span>
            <textarea
                name="description" 
                cols={60} 
                rows={5}
            />
        </label>
        <label htmlFor="">
            <span>상품이미지</span>
            <input id="img" type="file" name="img" />
        </label>
        <p>
            <button type="submit">확인</button>
            <button onClick={() => navigate('/')}>목록</button>
        </p>
      </Form>              
    </>
  );
};