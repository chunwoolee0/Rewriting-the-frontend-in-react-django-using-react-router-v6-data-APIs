import { useLoaderData } from "react-router-dom";
import axios from "axios";
import ProductItem from "./ProductItem";

export async function loader() {
    const q = await localStorage.getItem('q').trim();
    const url = q == ("null" || null) ? 'http://localhost/list' : `http://localhost/list?product_name=${q}`;
    let response;
    try {
        response = await axios.get(url);
        return response.data;
    } catch (error) {
        console.log(error.response);
    }
}

export default function ListProduct() {
    const items = useLoaderData();
    return (
        <>
            등록된 상품수: {items.length}
            <br />
            <br />
            <div
                style={{
                    display: "grid",
                    gridTemplateRows: "1fr",
                    gridTemplateColumns: "1fr 1fr 1fr 1fr 1fr",
                }}
            >
                {items.map(
                    ({ product_code, product_name, price, filename }) => (
                        <ProductItem
                            product_code={product_code}
                            product_name={product_name}
                            price={price}
                            filename={filename}
                            key={product_code}
                        />
                    )
                )}
            </div>           
        </>
    )
}