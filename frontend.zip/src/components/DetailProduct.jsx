import React from "react";
import axios from 'axios';
import "./main.css";
import { useNavigate, useLoaderData, Form, redirect } from "react-router-dom";

export async function loader({ params }) {
    const product_code = params.product_code;
    try {
        const response = await axios.get(`http://localhost/detail/${product_code}`);
        return response.data;
    } catch (error) {
        console.log(error.response);
    }
}

export async function action({ request }) {
    const formData = request.formData();
    const data = Object.fromEntries(formData);
    console.log("formData obj: ", data);

    // formData.set("img", img.current.files[0]);
    formData.set("img", document.getElementById("img").files[0]);
    try {
        const response = await fetch("http://localhost/update", {
            method: "post",
            encType: "multipart/form-data",
            body: formData,
        });
    } catch (error) {
        if (error.message) {
            console.log(error.message);
          } else {
            console.log(error);
          }
    }
    return redirect("/");
}
export default function DetailProduct() {
    const data = useLoaderData();
    const navigate = useNavigate();
    let src = "";
    let image_url = "";
    console.log("filename:" + data.filename);
    if (data.filename !== "-") {
        src = `http://localhost/static/images/${data.filename}`;
        image_url = `<img src=${src} width='300px' height='300px' />`;
    } else {
        image_url = "";
    }
    
    return (
        <>
            <Form method="post" id="product-form">
                <label>
                    <span>상품명</span>
                    <input
                        type="text"
                        name="product_name"
                        defaultValue={data.product_name}
                    />
                </label>
                <label>
                    <span>가격</span>
                    <input
                        type="number"
                        name="price"
                        defaultValue={data.price}
                    />
                </label>
                <label>
                    <span>상품설명</span>
                    <textarea
                        name="description" 
                        cols={60} 
                        rows={5}
                        defaultValue={data.description}
                    />
                </label>
                <label htmlFor="">
                    <span>상품이미지</span>
                    <span
                        dangerouslySetInnerHTML={{
                            __html: image_url,
                        }}
                    ></span>
                    <br />
                    <input id="img" type="file" name="img" />
                </label>
                <p>
                    <button type="submit">수정</button>
                </p>
            </Form>
            <Form
                method="post"
                action="destroy"
                onSubmit={(event) => {
                    if (!confirm("Please confirm you want to delete this item."))
                    {
                        event.preventDefault();
                    }
                }}
            >
                <button type="submit">Delete</button>
                <button
                    type="button"
                    onClick={() => {
                        navigate(-1);
                    }}
                    >
                    Cancel
                </button>
            </Form>
        </>
    );
}
