import { redirect } from 'react-router-dom';


export async function action({ params }) {
    try {
        await fetch(`http://localhost/delete?product_code=${params.product_code}`);
    } catch (error) {
        console.log(error);
    }
    return redirect("/");
}