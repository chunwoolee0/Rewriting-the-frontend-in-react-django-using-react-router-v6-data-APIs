import React from 'react'
import ReactDOM from 'react-dom/client'
import {
  createBrowserRouter,
  createRoutesFromElements,
  Route,
  RouterProvider,
  Form,
} from "react-router-dom";

import './index.css'
import Root, {
  loader as rootLoader,
  action as rootAction,
} from './components/Root';
import ListProduct,
{
  loader as listLoader,
} from './components/ListProduct';
import NewProduct, {
  action as newAction,
} from './components/NewProduct';
import DetailProduct, {
  loader as detailLoader,
  action as detailAction,
} from './components/DetailProduct';
import { action as destroyAction } from "./components/destroy";

const router = createBrowserRouter(
  createRoutesFromElements(
      <Route 
        path="/"
        element={<Root />}
        loader={rootLoader}
        action={rootAction}
      >
          <Route
            index={true}
            element={<ListProduct />}
            loader={listLoader}
          />
          <Route 
            path="new" 
            element={<NewProduct />}
            action={newAction}
          />
          <Route 
            path="detail/:product_code" 
            element={<DetailProduct />}
            loader={detailLoader}
            action={detailAction}
          />
          <Route 
            path="detail/:product_code/destroy" 
            action={destroyAction}
          />
      </Route>
  )
);

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
      <RouterProvider router={router} />
  </React.StrictMode>
);
